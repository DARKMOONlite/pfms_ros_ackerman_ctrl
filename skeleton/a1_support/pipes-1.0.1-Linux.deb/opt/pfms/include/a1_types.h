#ifndef A1_TYPES_H
#define A1_TYPES_H

namespace pfms {

    namespace commands {
        struct UGV{
            unsigned long seq;
            double brake; /*!< brake applied  [Nm] */
            double steering;
            double throttle;
        };

        struct UAV{
            unsigned long seq;
            double turn_l_r;
            double move_l_r;
            double move_u_d;
            double move_f_b;
        };
    }

    namespace nav_msgs{
        struct Odometry{
            unsigned long seq;
            double x;
            double y;
            double yaw;
            double vx;
            double vy;
        };
    }
    namespace geometry_msgs {
        struct Pose2D{
            double x;/*!< position x [m] */
            double y;/*!< position y [m] */
            double theta;/*!< angle [radians] */
        };
        struct Point{
            double x;/*!< position x [m] */
            double y;/*!< position y [m] */
        };

        struct Goal{
            unsigned long seq;
            Point point;
        };
    }

    typedef enum {
      ACKERMAN, /*!< Ackerman based steering ground vehicle */
      QUADCOPTER /*!< Quadcopter */
    } PlatformType; /*!< Platform Types */

}

#endif // A1_TYPES_H
