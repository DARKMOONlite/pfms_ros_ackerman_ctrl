// The producer-consumer problem implemented with POSIX IPC
// Copyright Guido Klingbeil (2013)
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
#ifndef PIPES_H
#define PIPES_H
#include <semaphore.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string>
#include <vector>

#include <atomic>
#include <mutex>
#include <condition_variable>
#include <thread>

#include "a1_types.h"

using std::string;

struct shm_details{
    string shmobj_path;
    string semobj_write;
    string semobj_read;
};


class Pipes
{
public:

    /*! @brief Pipes constructor.
     *
     *  Will establish the pipe (shared memory and sempahores by name) for communication
     *  @param length - length of the pipe, should be 1 higher than size of messages being sent (payload of message is length x double size [8bytes])
     *  @param shmobj_path - shared memory path
     *  @param semobj_write - sempahore for wrtting path
     *  @param semobj_read - sempahore for reading path
     */
    Pipes(unsigned int length, string shmobj_path, string semobj_write, string semobj_read);

    /*! @brief Pipes constructor that sets up a thread for reading/writing odometry
     *
     *  Will establish the pipe (shared memory and sempahores by name) for communication
     *  @param length - length of the pipe, should be 1 higher than size of messages being sent (payload of message is length x double size [8bytes])
     *  @param shmobj_path - shared memory path
     *  @param semobj_write - sempahore for wrtting path
     *  @param semobj_read - sempahore for reading path
     *  @param threadedOdod - indicates odometry will be threaded (so we can get current message)
     */
    Pipes(unsigned int length, string shmobj_path, string semobj_write, string semobj_read,
                 bool threadedOdo);

    /*! @brief Default constructor
     *
     *  Will establish the pipe (shared memory and sempahores by name) for communication
     *  length - 100
     *  shmobj_path - "/buffer_seg1"
     *  semobj_write - "/buffer_wsem1"
     *  semobj_read - "/buffer_rsem1"
     */
    Pipes();

    ~Pipes();

    /*! @brief Writes UGV command to the pipe, blocking call, will
     * be suspended until the pipe is available
     *
     *  @param ugv - the command to be written
     */
    void writeCommand(pfms::commands::UGV ugv);

    /*! @brief Writes UAV command to the pipe, blocking call, will
     * be suspended until the pipe is available
     *
     *  @param uav - the command to be written
     */
    void writeCommand(pfms::commands::UAV uav);

    /*! @brief Writes Odometry to the pipe, blocking call, will
     * be suspended until commend written or timeout (5s)
     *
     *  @param odo - the Odometry to be written
     *  @return true indicates is command written sucsesfully,
     * false timeout occured (pipe might not be open)
     */
    bool writeCommand(pfms::nav_msgs::Odometry odo);

    /*! @brief Writes Goal to the pipe, blocking call, will
     * be suspended until the pipe is available
     *
     *  @param goal - the goal to be written to pipe
     */
    void writeCommand(pfms::geometry_msgs::Goal goal);

    /*! @brief Reads UGV command from the pipe, blocking call, will
     * be suspended until commend written or timeout (5s)
     *
     *  @param ugv - the UGV Command from the pipe (read/wtite)
     *  @return true indicates is command written sucsesfully,
     * false timeout occured (pipe might not be open)
     */
    bool readCommand(pfms::commands::UGV& ugv);

    /*! @brief Reads UAV command from the pipe, blocking call, will
     * be suspended until commend written or timeout (5s)
     *
     *  @param uav - the UAV Command from the pipe (read/wtite)
     *  @return true indicates is command written sucsesfully,
     * false timeout occured (pipe might not be open)
     */
    bool readCommand(pfms::commands::UAV& uav);

    /*! @brief Reads Odometry from the pipe, blocking call, will
     * be suspended until commend written or timeout (5s)
     *
     *  @param odo - the Odometry from the pipe (read/wtite)
     *  @return true indicates is command written sucsesfully,
     * false timeout occured (pipe might not be open)
     */
    bool readCommand(pfms::nav_msgs::Odometry& odo);

    /*! @brief Reads Goal from the pipe, blocking call, will
     * be suspended until commend written or timeout (5s)
     *
     *  @param goal - the Goal from the pipe (read/wtite)
     *  @return true indicates is command written sucsesfully,
     * false timeout occured (pipe might not be open)
     */
    bool readCommand(pfms::geometry_msgs::Goal& goal);

    /*! @brief Thraed safe obtaining odometry @sa readOdo
     *
     *  @return the Odometry already obtained and stored.
     */
    pfms::nav_msgs::Odometry getOdo();//!<

    /*! @brief Provides the detaisl of names for shared memory
     * and semaphores
     *
     *  @return structure containing names
     */
    shm_details getShmDetails();

private:

    void writeBuffer(int i);
    bool readBuffer();

    /*! @brief Threaded version of reading Odometry, blocking call,
     * data retrieved via @sa getOdo
     */
    void readOdo();

    //ISSUE: static function needed for cleanup and accessing member values
    static void cleanup(int calledViaSignal);

private:

    sem_t * sem_write;/*!< Semaphore coordinating write acees, to be used with semaphore with read */
    sem_t * sem_read;//!< semaphore coordinating read acees, to be used with semaphore with write

    double* shmptr;//!< pointers to shared memory segments

    unsigned long shared_seg_size_;
    const unsigned int shmbuf_length_; //!< buffer length (int reflecting number of doubles)

    const string shmobj_path_; //!< name of the shared memory object
    const string semobj_write_; //!< name of semaphore for writing
    const string semobj_read_; //!< name of semaphore for read

    shm_details details_; //!< structure containing all names

    pfms::nav_msgs::Odometry odo_; //<! Local record of odometry;

    std::mutex mtx_; //<! mutex to protect odometry
    std::condition_variable cv_; //<! convar to synch getting Odo and reading odo
    std::atomic<bool> ready_; // Indicates if new odo data has been recieved
    std::vector<std::thread> threads_; // We add threads onto a vector here to be able to terminate then in destructor
    std::atomic<bool> running_; // We use this to indicate the loop in readOdo shoudl still be running
};

#endif // PIPES_H
