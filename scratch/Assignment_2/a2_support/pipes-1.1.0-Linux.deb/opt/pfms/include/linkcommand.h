#ifndef LINKCOMMAND_H
#define LINKCOMMAND_H

#include "a1_types.h"

class LinkCommand
{
public:
    LinkCommand();
    LinkCommand(bool debug);

    /*! @brief Sends the odometry that get's actioned via a service call to gazebo (the simulator). The change is instateneous
     *
     *  @param odo - The odometry, currently yaw is the only orientation used, the velocity is singnored (and set to zero)
     */
    bool writeCommand(pfms::nav_msgs::Odometry odo);

private:
    bool debug_;/*!< bool indicating if debug information to be provided */

};

#endif // LINKCOMMAND_H
